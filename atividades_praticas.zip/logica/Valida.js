/**
 * 
 */

class Valida{

	static negativo(num1){
		return (num1 < 0);

	}

	static positivo(num1){
		return (num1 > 0);
		
	}

	static neutro(num1){
		return (num1 == 0);
		
	}

	static par(num1){
		return ((num1 % 2) == 0);
		
	}

	static impar(num1){
		return ((num1 % 2) != 0);
		
	}

	static int(coisa){
		return 
	}








}